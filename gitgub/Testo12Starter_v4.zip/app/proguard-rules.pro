# Hilt / Dagger
-keep class dagger.hilt.** { *; }
-dontwarn dagger.hilt.**
-keep class javax.inject.** { *; }
-dontwarn javax.inject.**

# OkHttp / Retrofit / Moshi
-dontwarn okhttp3.**
-dontwarn okio.**
-dontwarn javax.annotation.**
-dontwarn com.squareup.okhttp3.**
-dontwarn com.squareup.moshi.**

# Kotlin coroutines
-dontwarn kotlinx.coroutines.**
