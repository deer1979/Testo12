package com.deercom.testo12.start

import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.deercom.data.prefs.PreferencesRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.launch

sealed interface StartState {
    data object Loading : StartState
    data object GoWelcome : StartState
    data object GoLogin : StartState
}

@HiltViewModel
class StartGateViewModel @Inject constructor(
    private val prefs: PreferencesRepository
) : ViewModel() {

    val state = mutableStateOf<StartState>(StartState.Loading)

    init {
        viewModelScope.launch {
            val setup = prefs.isSetupDone()
            state.value = if (setup) StartState.GoLogin else StartState.GoWelcome
        }
    }
}
