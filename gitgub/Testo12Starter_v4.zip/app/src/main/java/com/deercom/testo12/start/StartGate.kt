package com.deercom.testo12.start

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.hilt.navigation.compose.hiltViewModel

@Composable
fun StartGateScreen(
    onGoWelcome: () -> Unit,
    onGoLogin: () -> Unit,
    vm: StartGateViewModel = hiltViewModel()
) {
    val state by vm.state
    LaunchedEffect(state) {
        when (state) {
            is StartState.GoWelcome -> onGoWelcome()
            is StartState.GoLogin -> onGoLogin()
            else -> Unit
        }
    }
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        CircularProgressIndicator()
    }
}
