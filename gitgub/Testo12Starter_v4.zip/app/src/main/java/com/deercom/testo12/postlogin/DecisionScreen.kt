package com.deercom.testo12.postlogin

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.deercom.ui.components.AppTopBar

@Composable
fun DecisionScreen(
    onGoHome: () -> Unit,
    onCreateProfile: () -> Unit
) {
    Column(Modifier.fillMaxSize()) {
        AppTopBar("Configuración completada")
        Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Text("¡Listo! Tu empresa fue creada correctamente.")
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(onClick = onGoHome) { Text("Ir al Home") }
                OutlinedButton(onClick = onCreateProfile) { Text("Crear otro perfil") }
            }
        }
    }
}
