package com.deercom.testo12.nav

import androidx.compose.runtime.Composable
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.deercom.feature.onboarding.WelcomeScreen
import com.deercom.feature.onboarding.CompanyWizardScreen
import com.deercom.feature.auth.LoginScreen
import com.deercom.feature.home.HomeScreen
import com.deercom.feature.profiles.CreateProfileScreen
import com.deercom.testo12.start.StartGateScreen
import com.deercom.testo12.start.StartGateViewModel
import com.deercom.testo12.postlogin.DecisionScreen

object Routes {
    const val Start = "start"
    const val Welcome = "welcome"
    const val Wizard = "wizard"
    const val Login = "login"
    const val Decision = "decision"
    const val Home = "home"
    const val CreateProfile = "createProfile"
}

@Composable
fun AppNavGraph() {
    val nav = rememberNavController()
    NavHost(navController = nav, startDestination = Routes.Start) {
        composable(Routes.Start) {
            val vm: StartGateViewModel = hiltViewModel()
            StartGateScreen(
                onGoWelcome = { nav.navigate(Routes.Welcome) { popUpTo(Routes.Start) { inclusive = true } } },
                onGoLogin = { nav.navigate(Routes.Login) { popUpTo(Routes.Start) { inclusive = true } } },
                vm = vm
            )
        }
        composable(Routes.Welcome) {
            WelcomeScreen(onStart = { nav.navigate(Routes.Wizard) })
        }
        composable(Routes.Wizard) {
            CompanyWizardScreen(
                onSaved = {
                    nav.navigate(Routes.Login) {
                        popUpTo(Routes.Wizard) { inclusive = true }
                    }
                }
            )
        }
        composable(Routes.Login) {
            LoginScreen(
                onLoggedIn = {
                    nav.navigate(Routes.Decision) {
                        popUpTo(Routes.Login) { inclusive = true }
                    }
                }
            )
        }
        composable(Routes.Decision) {
            DecisionScreen(
                onGoHome = {
                    nav.navigate(Routes.Home) {
                        popUpTo(Routes.Decision) { inclusive = true }
                    }
                },
                onCreateProfile = {
                    nav.navigate(Routes.CreateProfile)
                }
            )
        }
        composable(Routes.Home) {
            HomeScreen(onSignOut = { nav.navigate(Routes.Login) { popUpTo(0) } })
        }
        composable(Routes.CreateProfile) {
            CreateProfileScreen(onDone = { nav.popBackStack() })
        }
    }
}
