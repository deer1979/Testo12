# Testo12 v4

Implementación del flujo completo de **onboarding**: Bienvenida → Wizard (4 tabs) → Foto → Guardar → Login → Decisión (Home / Crear perfil).

## Cambios clave
- **Versionado:** `versionCode=4`, `versionName=1.2.0-v4` (mismo package `com.deercom.testo12`).
- **Nuevos módulos:** `feature:onboarding`, `feature:profiles`.
- **UI/UX:** Tabs bloqueadas por validación, progreso, foto final (Photo Picker + CameraX), tema M3 profesional.
- **Red:** Retrofit/OkHttp listos (fakes por defecto). `NetworkModule` centralizado.
- **Debug/Release:** StrictMode (debug), Network Security Config (debug), shrink + minify (release).
- **Calidad:** ktlint/detekt + CI.

## Compilación
1. Abrir en Android Studio.
2. Sincronizar Gradle.
3. Ejecutar `app` (minSdk 23).

## Ajustes para backend real
- Reemplaza `BASE_URL` en `core/data/di/NetworkModule.kt`.
- Cambia `FakeCompanyRepository` y `FakeAuthRepository` por implementaciones reales que llamen `ApiService`.
