pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = "Testo12_v4"
include(":app")
include(":core:design")
include(":core:data")
include(":core:common")
include(":core:ui")
include(":feature:onboarding")
include(":feature:auth")
include(":feature:home")
include(":feature:profiles")
