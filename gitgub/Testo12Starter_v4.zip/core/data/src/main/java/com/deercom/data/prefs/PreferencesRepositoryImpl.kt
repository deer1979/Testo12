package com.deercom.data.prefs

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
Standing
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import dagger.Provides

private object Keys {
    val SetupDone = booleanPreferencesKey("setup_done")
    val AccessToken = stringPreferencesKey("access_token")
}

class PreferencesRepositoryImpl @Inject constructor(
    private val dataStore: DataStore<Preferences>
) : PreferencesRepository {
    override suspend fun setSetupDone(value: Boolean) {
        dataStore.edit { it[Keys.SetupDone] = value }
    }
    override suspend fun isSetupDone(): Boolean {
        return dataStore.data.map { it[Keys.SetupDone] ?: false }.first()
    }
    override suspend fun saveAccessToken(token: String?) {
        dataStore.edit { prefs ->
            if (token.isNullOrEmpty()) prefs.remove(Keys.AccessToken)
            else prefs[Keys.AccessToken] = token
        }
    }
    override suspend fun getAccessToken(): String? {
        return dataStore.data.map { it[Keys.AccessToken] }.first()
    }
}

@Module
@InstallIn(SingletonComponent::class)
object PreferencesModule {
    @Provides
    @Singleton
    fun bindPreferencesRepository(impl: PreferencesRepositoryImpl): PreferencesRepository = impl
}
