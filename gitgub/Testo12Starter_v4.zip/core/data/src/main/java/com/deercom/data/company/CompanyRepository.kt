package com.deercom.data.company

import android.net.Uri
import com.deercom.data.network.ApiService
import javax.inject.Inject

data class CompanyDraft(
    val name: String,
    val ruc: String?,
    val country: String?,
    val city: String?,
    val address: String?,
    val emailCorp: String?,
    val phone: String?,
    val website: String?,
    val currency: String,
    val timezone: String,
    val language: String,
    val policies: List<String>,
    val adminEmail: String,
    val adminPassword: String,
    val photoUri: Uri?
)

interface CompanyRepository {
    suspend fun createCompanyWithAdmin(draft: CompanyDraft): Result<String> // returns companyId
}

class FakeCompanyRepository @Inject constructor(
    private val api: ApiService
) : CompanyRepository {
    override suspend fun createCompanyWithAdmin(draft: CompanyDraft): Result<String> {
        // Simulación local exitosa
        if (draft.name.isBlank()) return Result.failure(IllegalArgumentException("Nombre requerido"))
        if (draft.adminEmail.isBlank() || draft.adminPassword.length < 6)
            return Result.failure(IllegalArgumentException("Admin inválido"))
        return Result.success("cmp-001")
    }
}
