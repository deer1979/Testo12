package com.deercom.data.prefs

interface PreferencesRepository {
    suspend fun setSetupDone(value: Boolean)
    suspend fun isSetupDone(): Boolean
    suspend fun saveAccessToken(token: String?)
    suspend fun getAccessToken(): String?
}
