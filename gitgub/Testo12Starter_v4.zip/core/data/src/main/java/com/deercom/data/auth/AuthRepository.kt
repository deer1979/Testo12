package com.deercom.data.auth

import com.deercom.data.network.ApiService
import com.deercom.data.network.LoginRequestDto
import javax.inject.Inject

data class User(val id: String, val email: String, val role: String, val companyId: String)

interface AuthRepository {
    suspend fun signIn(email: String, password: String): Result<User>
    suspend fun signOut()
}

class FakeAuthRepository @Inject constructor(
    private val api: ApiService
) : AuthRepository {
    override suspend fun signIn(email: String, password: String): Result<User> {
        // Simulación local (no llamar a red por defecto)
        return if (email.isNotBlank() && password.length >= 4) {
            Result.success(User("u1", email, "ADMIN_MASTER", "cmp-001"))
        } else {
            Result.failure(IllegalArgumentException("Credenciales inválidas"))
        }
    }

    override suspend fun signOut() { /* no-op */ }
}
