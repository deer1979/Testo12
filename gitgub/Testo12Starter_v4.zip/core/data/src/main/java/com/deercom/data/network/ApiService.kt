package com.deercom.data.network

import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Multipart
import retrofit2.http.POST
import retrofit2.http.Part
import retrofit2.http.Path
import okhttp3.MultipartBody
import retrofit2.Response

data class CompanyDraftDto(
    val name: String,
    val ruc: String?,
    val country: String?,
    val city: String?,
    val address: String?,
    val emailCorp: String?,
    val phone: String?,
    val website: String?,
    val currency: String,
    val timezone: String,
    val language: String,
    val policies: List<String>
)

data class CompanyCreatedDto(val companyId: String, val createdAt: String)
data class CreateUserDto(val companyId: String, val email: String, val password: String, val role: String)
data class CreatedUserDto(val userId: String)
data class LoginRequestDto(val email: String, val password: String)
data class LoginResponseDto(val accessToken: String, val refreshToken: String, val userId: String, val role: String, val companyId: String)

interface ApiService {
    @GET("ping")
    suspend fun ping(): Response<Unit>

    @POST("companies")
    suspend fun createCompany(@Body body: CompanyDraftDto): Response<CompanyCreatedDto>

    @POST("users")
    suspend fun createUser(@Body body: CreateUserDto): Response<CreatedUserDto>

    @POST("auth/login")
    suspend fun login(@Body body: LoginRequestDto): Response<LoginResponseDto>

    @Multipart
    @POST("media/company/{companyId}/photo")
    suspend fun uploadCompanyPhoto(
        @Path("companyId") companyId: String,
        @Part file: MultipartBody.Part
    ): Response<Unit>
}
