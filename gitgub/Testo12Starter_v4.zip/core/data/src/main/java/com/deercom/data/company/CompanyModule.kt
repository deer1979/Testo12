package com.deercom.data.company

import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object CompanyModule {
    @Provides
    @Singleton
    fun provideCompanyRepository(impl: FakeCompanyRepository): CompanyRepository = impl
}
