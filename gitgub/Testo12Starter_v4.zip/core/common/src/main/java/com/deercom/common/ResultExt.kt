package com.deercom.common

inline fun <T> Result<T>.onSuccessDo(block: (T) -> Unit): Result<T> {
    if (isSuccess) getOrNull()?.let(block)
    return this
}

inline fun <T> Result<T>.onFailureDo(block: (Throwable) -> Unit): Result<T> {
    exceptionOrNull()?.let(block)
    return this
}
