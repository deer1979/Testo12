package com.deercom.design

import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val BrandBlue = Color(0xFF1E88E5)
private val BrandBlueDark = Color(0xFF1565C0)
private val BrandTeal = Color(0xFF00BFA5)
private val BrandTealDark = Color(0xFF00897B)
private val BrandError = Color(0xFFB00020)

private val LightColors = lightColorScheme(
    primary = BrandBlue,
    onPrimary = Color.White,
    primaryContainer = Color(0xFF90CAF9),
    onPrimaryContainer = Color(0xFF0D47A1),
    secondary = BrandTeal,
    onSecondary = Color.Black,
    secondaryContainer = Color(0xFF80CBC4),
    onSecondaryContainer = Color(0xFF004D40),
    error = BrandError
)

private val DarkColors = darkColorScheme(
    primary = BrandBlueDark,
    onPrimary = Color.White,
    primaryContainer = Color(0xFF0D47A1),
    onPrimaryContainer = Color.White,
    secondary = BrandTealDark,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFF004D40),
    onSecondaryContainer = Color.White,
    error = BrandError
)

@Composable
fun Testo12Theme(
    darkTheme: Boolean = false,
    content: @Composable () -> Unit
) {
    val colors: ColorScheme = if (darkTheme) DarkColors else LightColors
    MaterialTheme(
        colorScheme = colors,
        typography = androidx.compose.material3.Typography(),
        content = content
    )
}
