package com.deercom.feature.home

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.deercom.ui.components.AppTopBar

@Composable
fun HomeScreen(onSignOut: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        AppTopBar("Home")
        Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Bienvenido a Testo12 v4", style = MaterialTheme.typography.headlineSmall)
            Text("Starter listo: wizard, foto y flujo post-login implementados.")
            Button(onClick = onSignOut) { Text("Cerrar sesión") }
        }
    }
}
