package com.deercom.feature.auth

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.deercom.ui.components.AppTopBar
import androidx.hilt.navigation.compose.hiltViewModel

@Composable
fun LoginScreen(
    onLoggedIn: () -> Unit,
    vm: LoginViewModel = hiltViewModel()
) {
    val uiState by vm.uiState.collectAsState()
    var form by remember { mutableStateOf(LoginForm()) }

    if (uiState is LoginUiState.Success) {
        LaunchedEffect(Unit) { onLoggedIn() }
    }

    Column(Modifier.fillMaxSize()) {
        AppTopBar(title = "Login")
        Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(value = form.email, onValueChange = { form = form.copy(email = it) }, label = { Text("Email") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(
                value = form.password,
                onValueChange = { form = form.copy(password = it) },
                label = { Text("Password") },
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth()
            )
            val loading = uiState is LoginUiState.Loading
            Button(onClick = { vm.signIn(form) }, enabled = !loading, modifier = Modifier.fillMaxWidth()) {
                Text(if (loading) "Ingresando..." else "Ingresar")
            }
            val error = (uiState as? LoginUiState.Error)?.message
            if (error != null) {
                Text(error, color = MaterialTheme.colorScheme.error)
            }
        }
    }
}
