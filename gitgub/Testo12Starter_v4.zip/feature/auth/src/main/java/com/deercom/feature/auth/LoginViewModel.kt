package com.deercom.feature.auth

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.deercom.data.auth.AuthRepository
import com.deercom.data.prefs.PreferencesRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class LoginForm(val email: String = "", val password: String = "")

sealed interface LoginUiState {
    data object Idle : LoginUiState
    data object Loading : LoginUiState
    data object Success : LoginUiState
    data class Error(val message: String) : LoginUiState
}

@HiltViewModel
class LoginViewModel @Inject constructor(
    private val auth: AuthRepository,
    private val prefs: PreferencesRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow<LoginUiState>(LoginUiState.Idle)
    val uiState = _uiState.asStateFlow()

    fun signIn(form: LoginForm) {
        viewModelScope.launch {
            _uiState.value = LoginUiState.Loading
            val res = auth.signIn(form.email.trim(), form.password)
            _uiState.value = res.fold(
                onSuccess = {
                    viewModelScope.launch { prefs.saveAccessToken("token-demo") }
                    LoginUiState.Success
                },
                onFailure = { LoginUiState.Error(it.message ?: "Error") }
            )
        }
    }
}
