package com.deercom.feature.onboarding

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.hilt.navigation.compose.hiltViewModel
import coil.compose.AsyncImage

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CompanyWizardScreen(
    onSaved: () -> Unit,
    vm: CompanyWizardViewModel = hiltViewModel()
) {
    val form by vm.form.collectAsState()
    val ui by vm.ui.collectAsState()

    if (ui is WizardUiState.Success) {
        LaunchedEffect(Unit) { onSaved() }
    }

    val pagerState = rememberPagerState(pageCount = { 4 })
    val tabs = listOf("Empresa", "Contacto", "Preferencias", "Resumen & Foto")

    Column(Modifier.fillMaxSize()) {
        TopAppBar(title = { Text("Configuración (Paso ${'$'}{pagerState.currentPage + 1}/4)") })
        ScrollableTabRow(selectedTabIndex = pagerState.currentPage) {
            tabs.forEachIndexed { index, title ->
                Tab(selected = pagerState.currentPage == index, onClick = { /* locked by Next/Back */ }, text = { Text(title) })
            }
        }

        HorizontalPager(state = pagerState, userScrollEnabled = false, modifier = Modifier.weight(1f)) { page ->
            when (page) {
                0 -> TabEmpresa(form) { vm.update { it.copy(
                        name = it.name,
                        ruc = it.ruc,
                        country = it.country,
                        city = it.city,
                        address = it.address
                    ) } }
                1 -> TabContacto(form) { updated -> vm.update { it.copy(
                        emailCorp = updated.emailCorp,
                        phone = updated.phone,
                        website = updated.website,
                        adminEmail = updated.adminEmail,
                        adminPassword = updated.adminPassword
                    ) } }
                2 -> TabPreferencias(form) { updated -> vm.update { it.copy(
                        currency = updated.currency,
                        timezone = updated.timezone,
                        language = updated.language,
                        policies = updated.policies
                    ) } }
                3 -> TabResumenFoto(form,
                    onPick = { uri -> vm.update { it.copy(photoUri = uri) } },
                    onClear = { vm.update { it.copy(photoUri = null) } }
                )
            }
        }

        val canNext = when (pagerState.currentPage) {
            0 -> form.isTab1Valid()
            1 -> form.isTab2Valid()
            2 -> form.isTab3Valid()
            else -> true
        }
        val canBack = pagerState.currentPage > 0

        Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { if (canBack) LaunchedEffect(Unit) { pagerState.animateScrollToPage(pagerState.currentPage - 1) } }, enabled = canBack) {
                Text("Anterior")
            }
            Spacer(Modifier.weight(1f))
            if (pagerState.currentPage < 3) {
                Button(onClick = { if (canNext) LaunchedEffect(Unit) { pagerState.animateScrollToPage(pagerState.currentPage + 1) } }, enabled = canNext) {
                    Text("Siguiente")
                }
            } else {
                val loading = ui is WizardUiState.Submitting
                Button(onClick = { vm.save() }, enabled = !loading) {
                    Text(if (loading) "Guardando..." else "Guardar")
                }
            }
        }

        val error = (ui as? WizardUiState.Error)?.message
        if (error != null) {
            Text(error, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(16.dp))
        }
    }
}

@Composable
private fun TabEmpresa(form: CompanyWizardState, onEdit: () -> Unit) {
    var name by remember { mutableStateOf(form.name) }
    var ruc by remember { mutableStateOf(form.ruc) }
    var country by remember { mutableStateOf(form.country) }
    var city by remember { mutableStateOf(form.city) }
    var address by remember { mutableStateOf(form.address) }

    LaunchedEffect(name, ruc, country, city, address) { onEdit() }

    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Razón social*") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = ruc, onValueChange = { ruc = it }, label = { Text("RUC") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = country, onValueChange = { country = it }, label = { Text("País") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = city, onValueChange = { city = it }, label = { Text("Ciudad") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = address, onValueChange = { address = it }, label = { Text("Dirección") }, modifier = Modifier.fillMaxWidth())
    }
}

data class ContactoForm(val emailCorp: String, val phone: String, val website: String, val adminEmail: String, val adminPassword: String)

@Composable
private fun TabContacto(form: CompanyWizardState, onChange: (ContactoForm) -> Unit) {
    var emailCorp by remember { mutableStateOf(form.emailCorp) }
    var phone by remember { mutableStateOf(form.phone) }
    var website by remember { mutableStateOf(form.website) }
    var adminEmail by remember { mutableStateOf(form.adminEmail) }
    var adminPassword by remember { mutableStateOf(form.adminPassword) }

    LaunchedEffect(emailCorp, phone, website, adminEmail, adminPassword) {
        onChange(ContactoForm(emailCorp, phone, website, adminEmail, adminPassword))
    }

    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        OutlinedTextField(value = emailCorp, onValueChange = { emailCorp = it }, label = { Text("Email corporativo") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("Teléfono") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = website, onValueChange = { website = it }, label = { Text("Sitio web") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = adminEmail, onValueChange = { adminEmail = it }, label = { Text("Email Admin*") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = adminPassword, onValueChange = { adminPassword = it }, label = { Text("Password Admin* (6+)") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
    }
}

data class PrefsForm(val currency: String, val timezone: String, val language: String, val policies: List<String>)

@Composable
private fun TabPreferencias(form: CompanyWizardState, onChange: (PrefsForm) -> Unit) {
    var currency by remember { mutableStateOf(form.currency) }
    var timezone by remember { mutableStateOf(form.timezone) }
    var language by remember { mutableStateOf(form.language) }
    var requirePhoto by remember { mutableStateOf(false) }

    LaunchedEffect(currency, timezone, language, requirePhoto) {
        val policies = buildList { if (requirePhoto) add("require_work_order_photo") }
        onChange(PrefsForm(currency, timezone, language, policies))
    }

    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        OutlinedTextField(value = currency, onValueChange = { currency = it }, label = { Text("Moneda*") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = timezone, onValueChange = { timezone = it }, label = { Text("Zona horaria*") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = language, onValueChange = { language = it }, label = { Text("Idioma") }, modifier = Modifier.fillMaxWidth())
        Row {
            Checkbox(checked = requirePhoto, onCheckedChange = { requirePhoto = it })
            Text("Requiere fotos de orden de trabajo")
        }
    }
}

@Composable
private fun TabResumenFoto(
    form: CompanyWizardState,
    onPick: (Uri?) -> Unit,
    onClear: () -> Unit
) {
    val context = LocalContext.current
    val pickLauncher = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        onPick(uri)
    }
    val cameraPerm = Manifest.permission.CAMERA
    val camPermGranted = remember {
        mutableStateOf(ContextCompat.checkSelfPermission(context, cameraPerm) == PackageManager.PERMISSION_GRANTED)
    }
    val requestPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        camPermGranted.value = granted
    }

    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Resumen", style = MaterialTheme.typography.titleLarge)
        Text("Empresa: ${'$'}{form.name.ifBlank { "(sin nombre)" }} | Admin: ${'$'}{form.adminEmail.ifBlank { "(sin email)" }}")
        if (form.photoUri != null) {
            AsyncImage(model = form.photoUri, contentDescription = "Foto seleccionada", modifier = Modifier.fillMaxWidth().height(200.dp))
            OutlinedButton(onClick = onClear) { Text("Quitar foto") }
        } else {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { pickLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }) {
                    Text("Elegir de galería")
                }
                Button(onClick = {
                    if (!camPermGranted.value) requestPerm.launch(cameraPerm)
                    else PhotoCaptureDialog(onCaptured = onPick).show()
                }) {
                    Text("Tomar foto")
                }
            }
        }
        Text("Puedes continuar sin foto (opcional).")
    }
}
