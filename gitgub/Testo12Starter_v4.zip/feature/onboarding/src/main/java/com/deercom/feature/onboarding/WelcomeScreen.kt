package com.deercom.feature.onboarding

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.deercom.ui.components.AppTopBar

@Composable
fun WelcomeScreen(onStart: () -> Unit) {
    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
        AppTopBar("Bienvenido")
        Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Text("Bienvenido a Testo12", style = MaterialTheme.typography.headlineSmall)
            Text("Vamos a configurar tu empresa y el Admin Maestro.")
            Button(onClick = onStart) { Text("Comenzar configuración") }
        }
    }
}
