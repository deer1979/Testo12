package com.deercom.feature.onboarding

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.deercom.data.company.CompanyDraft
import com.deercom.data.company.CompanyRepository
import com.deercom.data.prefs.PreferencesRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class CompanyWizardState(
    // Tab 1
    val name: String = "",
    val ruc: String = "",
    val country: String = "",
    val city: String = "",
    val address: String = "",
    // Tab 2
    val emailCorp: String = "",
    val phone: String = "",
    val website: String = "",
    val adminEmail: String = "",
    val adminPassword: String = "",
    // Tab 3
    val currency: String = "USD",
    val timezone: String = "America/Guayaquil",
    val language: String = "es",
    val policies: List<String] = emptyList(),
    // Tab 4
    val photoUri: Uri? = null
) {
    fun isTab1Valid() = name.isNotBlank()
    fun isTab2Valid() = adminEmail.isNotBlank() && adminPassword.length >= 6
    fun isTab3Valid() = currency.isNotBlank() && timezone.isNotBlank()
    fun isAllValid() = isTab1Valid() && isTab2Valid() && isTab3Valid()
}

sealed interface WizardUiState {
    data object Idle : WizardUiState
    data object Submitting : WizardUiState
    data class Error(val message: String) : WizardUiState
    data object Success : WizardUiState
}

@HiltViewModel
class CompanyWizardViewModel @Inject constructor(
    private val repo: CompanyRepository,
    private val prefs: PreferencesRepository
) : ViewModel() {

    private val _form = MutableStateFlow(CompanyWizardState())
    val form = _form.asStateFlow()

    private val _ui = MutableStateFlow<WizardUiState>(WizardUiState.Idle)
    val ui = _ui.asStateFlow()

    fun update(transform: (CompanyWizardState) -> CompanyWizardState) {
        _form.value = transform(_form.value)
    }

    fun save() {
        val current = _form.value
        if (!current.isAllValid()) {
            _ui.value = WizardUiState.Error("Completa los campos obligatorios")
            return
        }
        viewModelScope.launch {
            _ui.value = WizardUiState.Submitting
            val draft = CompanyDraft(
                name = current.name.trim(),
                ruc = current.ruc.ifBlank { null },
                country = current.country.ifBlank { null },
                city = current.city.ifBlank { null },
                address = current.address.ifBlank { null },
                emailCorp = current.emailCorp.ifBlank { null },
                phone = current.phone.ifBlank { null },
                website = current.website.ifBlank { null },
                currency = current.currency,
                timezone = current.timezone,
                language = current.language,
                policies = current.policies,
                adminEmail = current.adminEmail.trim(),
                adminPassword = current.adminPassword,
                photoUri = current.photoUri
            )
            val res = repo.createCompanyWithAdmin(draft)
            _ui.value = res.fold(
                onSuccess = {
                    viewModelScope.launch { prefs.setSetupDone(true) }
                    WizardUiState.Success
                },
                onFailure = { WizardUiState.Error(it.message ?: "Error") }
            )
        }
    }
}
