package com.deercom.feature.profiles

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.deercom.ui.components.AppTopBar

@Composable
fun CreateProfileScreen(onDone: () -> Unit) {
    var email by remember { mutableStateOf("") }
    var role by remember { mutableStateOf("ADMIN") }
    Column(Modifier.fillMaxSize()) {
        AppTopBar("Crear perfil")
        Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("Email") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = role, onValueChange = { role = it }, label = { Text("Rol (ADMIN/OPERATOR/TECH)") }, modifier = Modifier.fillMaxWidth())
            Button(onClick = onDone, modifier = Modifier.fillMaxWidth()) { Text("Guardar perfil") }
        }
    }
}
